strtrimspace <- function(...) {
  .Deprecated(new="strstrip")
}

setCN <- function(...) {
	.Deprecated(new="setchs")
}

